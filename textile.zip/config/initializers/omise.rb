Omise.api_key = Rails.application.secrets.omise_skey
Omise.vault_key = Rails.application.secrets.omise_pkey
